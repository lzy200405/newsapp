package com.example.newsapp.fragment;

import android.os.Bundle;
import android.view.*;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.newsapp.R;
import com.example.newsapp.adapter.NewsAdapter;
import com.example.newsapp.model.News;
import com.example.newsapp.utils.SharedPrefsUtils;

import java.util.*;

public class FavoriteFragment extends Fragment {
    RecyclerView recyclerView;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_favorite, container, false);
        recyclerView = v.findViewById(R.id.recyclerFavorites);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        List<String> urls = SharedPrefsUtils.getFavorites(getContext());
        List<News> newsList = new ArrayList<>();
        for (String url : urls) {
            newsList.add(new News("已收藏新闻", "收藏", url, "", ""));
        }

        recyclerView.setAdapter(new NewsAdapter(newsList, getContext(), false));
        return v;
    }
}
